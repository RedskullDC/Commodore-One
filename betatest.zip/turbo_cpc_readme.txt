TurboCPC by TobiFlex


To run the TurboCPC you need an SDRAM Module PC100 2-2-2 or PC133 2-2-2 or 3-3-3.

To run The TurboCPC please make sure to flash to V0.46 of the system flash. (\root\cone-sys.bin)
Functionkeys:
F5 - 50Hz vertical monitor frequency (after reset with F12)
F6 - 60Hz vertical monitor frequency (after reset with F12)
F7 same as F5
F8 DSK menue
  you can choose a DSK image with the arrowkeys and load it with ENTER. 
After loading the screen returns to the CPC.
F9 - CloneCPC(default 4Mhz)
F10 - TurboCPC(12MHz Z80)

ROM names in the boot folder (binary, without AMSDOS Header).
4r040000.bin: Kernal
4r044000.bin: Basic
4r05C000.bin: AMSDOSrom

If you would like use other ROMs:

ROM2 = 4r048000.bin
ROM3 = 4r04C000.bin
ROM4 = 4r050000.bin
ROM5 = 4r054000.bin
ROM6 = 4r058000.bin
ROM7 = 4r05C000.bin


greetings,
TobiFlex




