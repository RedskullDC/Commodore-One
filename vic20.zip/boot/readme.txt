VC20 by MikeJ
http://home.freeuk.com/fpgaarcade/vic20_main.htm
Ported to the C-One by TobiFlex.

Full sources included!

