#ifndef _FAT16182_H_INCLUDED
#define _FAT16182_H_INCLUDED

struct file2TYPE
{
	unsigned char name[12];   			/*name of file*/
	unsigned char attributes;
	unsigned short entry;				/*file-entry index in directory table*/
	unsigned short sec;  				/*sector index in file*/
	unsigned long len;					/*file size*/
	unsigned long cluster;				/*first file cluster*/	
};

/*global sector buffer, data for read/write actions is stored here.
BEWARE, this buffer is also used and thus trashed by all other functions*/
extern unsigned long volstart;					/*start LBA of Volume*/
extern unsigned long fatstart;					/*start LBA of first FAT table*/
extern unsigned long datastart;       			/*start LBA of data field*/
extern unsigned long dirstart;   				/*start LBA of directory table*/
//extern unsigned char fatno; 					/*number of FAT tables*/
extern unsigned short clustersize;     			/*size of a cluster in blocks*/
extern unsigned short rootdirentrys;     			/*number of entry's in directory table*/
extern unsigned long fatstart;					/*start LBA of first FAT table*/
extern unsigned char secbuf[512];		/*sector buffer*/
extern unsigned long cluster;   				/*current cluster */
extern unsigned long sectorlba;   				/*current LBA */
extern unsigned short sectorcnt;				/*current sector in cluster */
extern unsigned long cachelba;   				/*current LBA */
extern unsigned short cachevalid;
extern unsigned short drive;
extern unsigned long rootsector;   				/*rootsector */
extern unsigned long rootcluster;   			/*rootcluster */
extern unsigned short attrib;

/*constants*/
#define FILESEEK_START			0		/*start search from beginning of directory*/
#define	FILESEEK_NEXT			1		/*find next file in directory*/
#define	FILESEEK_PREV			2		/*find previous file in directory*/

/*functions*/
//unsigned char FindDrive2(void);
//unsigned char FileSearch2(struct file2TYPE *file, unsigned char mode);
//unsigned char FileNextSector2(struct file2TYPE *file);
//unsigned char FileRead2(struct file2TYPE *file);
//unsigned char FileWrite2(struct file2TYPE *file);

#endif
