/*
Copyright 2005, 2006, 2007 Dennis van Weeren

This file is part of Minimig

Minimig is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

Minimig is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

This is a simple FAT16 handler. It works on a sector basis to allow fastest acces on disk
images.

11-12-2005		-first version, ported from FAT1618.C
*/

#include <stdio.h>
#include "fat1618_2.h"

/*internal global variables*/
static unsigned long volstart;					/*start LBA of Volume*/
static unsigned long fatstart;					/*start LBA of first FAT table*/
static unsigned long dirstart;   				/*start LBA of directory table*/
static unsigned long datastart;       			/*start LBA of data field*/
//static unsigned char fatno; 					/*number of FAT tables*/
static unsigned short clustersize;     			/*size of a cluster in blocks*/
static unsigned short rootdirentrys;     			/*number of entry's in directory table*/
static unsigned char secbuf[512];						/*sector buffer*/
static unsigned long cluster;   				/*current cluster */
static unsigned long sectorlba;   				/*current LBA */
static unsigned long cachelba;   				/*current LBA */
static unsigned short cachevalid;
static unsigned short sectorcnt;				/*current sector in cluster */
static unsigned short drive;
static unsigned long rootsector;   				/*rootsector */
static unsigned long rootcluster;   			/*rootcluster */
static unsigned short attrib;

