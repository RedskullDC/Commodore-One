I would like to write some little useful C-One Cores to show the possible future of the board.

This second part is a picture viewer for 65536 colors. The picture must be 640x480 pixels in size. The picture is stored in the SDRAM after FPGA configuration (as opposed to prior copying with the previous system flashes - see the readme of the new version V0.48!). 

You can convert your own image with Irfanview in a RGB RAW mode and 640x480. Then convert it with raw2cone in the c-one raw mode:
B 5bit, G 6bit, R 5bit.
Rename the cone.raw file into 7r0E0000.bin and store it into the boot folder.


This archive includes the files for the boot folder, the quartus 5.0 snapshot of the FPGA source, and the cpp-source for the raw2cone converter.

What do you think about these cores?


Enjoy
TobiFlex  


