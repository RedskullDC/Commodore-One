system flash V0.46

added code to be compatible with Turbo CPC core.


system flash V0.44

- new IDE/flashcard timing should improve compatibility

- some cleanup in BitBoot, handling of cards with lots of deleted files debugged

- Silversurfer is now only used on it's upper mirror addresses (future compatibility with other clockport products)

- BigBoot now initializes the S-Ram on the CPU/RAM card with 0, so the C64 core does not need an init memory file any more. This also ensures safe startup of all cores.

- inner loop of the IDE poll routine now written in RISC assembler, improving speed by 25%
