=======================================
*     ___       ____  _    ___  ___   *
*    /__  /__/ / / / /_\  /  / /__    *
*   ___/ ___/ /   / /__/ /__/ ___/    *
*       SYMBIOSIS MULTITASKING        *
*       BASED OPERATING SYSTEM        *
=======================================
S T A R K O S   S O N G   M O D U L E S
 Artists: Targhan/Arkos and Fenyx Kell
 PLEASE USE SYMAMP TO PLAY THIS SONGS
---------------------------------------
Music-STarKos.DSK contains:
---------------------------------------
SONG           COMPOSER
akscreen.skm - Madmax/TEX (ST)
               [conv. by Targhan/Arkos]
cooltry.skm  - Targhan/Arkos
killer.skm   - Big Alec/Delta Force(ST)
               [conv. by Targhan/Arkos]
lxcess.skm   - Madmax/TEX (ST)
               [conv. by Targhan/Arkos]
megadist.skm - Count Zero (ST)
               [conv. by Targhan/Arkos]
ooops.skm    - Targhan/Arkos
tcbsprit.skm - Madmax/TEX (ST)
               [conv. by Targhan/Arkos]
landfm.skm   - Targhan/Arkos(DemoIzArt)
octopus.skm  - Targhan/Arkos(DemoIzArt)
suprapok.skm - Targhan/Arkos(DemoIzArt)
carpet.skm   - Targhan/Arkos(MidlineP.)
molusk.skm   - Targhan/Arkos(MidlineP.)
bd10oeuf.skm - Fenyx Kell
smok50hz.skm - Fenyx Kell
smokbd10.skm - Fenyx Kell
bobline.skm  - Fenyx Kell
---------------------------------------
    For more information about this
        collection please visit
   http://www.symbos.de/download.htm
=======================================
