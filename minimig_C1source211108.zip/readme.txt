Thanks a lot to Dennis van Weeren and Jakub Bednarski!

The Minimig source code is open-source, therefore we also open up the source
of this port, including all changes for the C-One. All files are under GPL, with
the exception of the TG68 processor core: For TG68 V1.04, LGPL has been chosen.

The directory "C1extender" contains the Quartus snapshot.
The directory "C1extender\jbrom" contains the C/ASM code for the 68000 Controller.
The directory "minimig" contains Minimig :-)
The directory "1K30" contains the IO-connection core. It makes the C-One's interfaces available
to the FPGA extender card.
The directory "ntsc" contains the toplevel design of the NTSC core.

Viele Gr��e
TobiFlex
(Tobias Gubener)
(translation by Jens Sch�nfeld)
