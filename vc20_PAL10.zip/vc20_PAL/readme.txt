VC20 by MikeJ
http://home.freeuk.com/fpgaarcade/vic20_main.htm
Transfer into the C-One by TobiFlex.

To run the VC20 you need the ROMs in the boot folder.
rename the basicrom to  3r04c000.bin
rename the kernalrom to 3r04e000.bin
rename the charrom to   3r050000.bin

This is the first beta of the PAL-Core.
IEC support follows later.
TobiFlex




