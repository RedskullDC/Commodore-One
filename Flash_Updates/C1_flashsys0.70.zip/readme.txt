Flashsys V070

This version now contains the first alpha version of a 1541-emulation. Att his point, only LOAD from subchannel 0 works - no OPEN, no CLOSE, no SAVE. If you do not use the rom file, there's no change to the previous version. Using the rom file with a core that uses the IEC port (including Jeri's C64 core, Peter's PAL core and Tobias' VIC-20 core), Just like in the CPC core, press F8 to choose D64 images or to load PRG-files. Using this core together with a real floppy on the IEC-port is not possible at this point.

Re-name the rom file to have it available under the core numbers you want to use it with. 

The default drive number is 9, but can be changed to 8 in the menu that appears when pressing F8. Press U in that menu to deactivate the drive emulation, press 8 or 9 to activate it.

Many thanks to Tobias Gubener for his unbreakable enthousiasm about the C-One. This is really a great demonstration of the power of re-configurable computing!
