VC20 by MikeJ
http://home.freeuk.com/fpgaarcade/vic20_main.htm
Ported to the C-One by TobiFlex.

ROM names in the boot folder:
3r04c000.bin: Basic
3r04e000.bin: Kernal
3r050000.bin: character

This is the second beta of the PAL-Core with IEC support.
TobiFlex




