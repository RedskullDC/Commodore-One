The current projekt is for a pal minimig core.
If you like compile a ntsc minimig, copy the file "extender.bdf" in your project and overwrite the current file.