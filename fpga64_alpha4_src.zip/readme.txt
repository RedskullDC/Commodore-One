FPGA64 by Peter Wendrich
Release Alpha 4
date: february 14th, 2006

new implementation of VIC-II logic and the scandoubler, so it's now possible to switch between PAL and NTSC on the fly! Use the F12 key to switch between the two modes.

Peter also fixed some bugy in the MMU that he added to the CPU, the magic registers $AB and $CD that protect the core-specific register-set are now working as described in the docs.

Also, the "rolling" VGA display that some people have reported are hopefully gone. This is difficult to determine for us, as we only have a limited choice of monitors here. The one thing we found out is that the Commodore 1942 monitor, although it *should* work with 50Hz, does not work properly with 50Hz. It starts syncing fine at 60Hz. Please report your experience, as this might help us in finding the fault - either a defective 1942, or some inconsistency in the cote.

Still no correct sprites in this core, but Peter is getting close. Please do some tests with this core, and report whatever you find!

have fun,

Peter and Jens
