=======================================
*     ___       ____  _    ___  ___   *
*    /__  /__/ / / / /_\  /  / /__    *
*   ___/ ___/ /   / /__/ /__/ ___/    *
*       SYMBIOSIS MULTITASKING        *
*       BASED OPERATING SYSTEM        *
=======================================
   B S C   S O U N D   T R A K K E R
        S O N G   M O D U L E S
        Artist: BSC / SymbiosiS
 PLEASE USE SYMAMP TO PLAY THIS SONGS
---------------------------------------
#STBSC1.DSK - BSC Songs 1/2
#STBSC2.DSK - BSC Songs 2/2
---------------------------------------
    For more information about this
        collection please visit
   http://www.symbos.de/download.htm
=======================================
