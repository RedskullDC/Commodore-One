system flash V0.48

This new version now allows control over the time when the rom files are transferred to the 1k100 FPGA. BigBoot makes the decision depending on the name: All rom files for the area between $040000 and $05ffff are transferred to the S-Ram prior to configuration of the 1k100 FPGA. After configuration, all other files are sent to the newly configured FPGA, giving the possibility to transfer up to 640KByte in one file. Be sure NOT to overwrite $080000 to $0dffff, because this will also overwrite the early startup code on the 1k30 side.
Hint: After reaching address $0fffff, the address counter will wrap around to $000000, because the address sapce is limited to 1MB. 

system flash V0.47

new 1k30 core implements new GBmux functions, such as a new graphics mode with 33Mhz and 4096 colours. This new mode is being used by the new TurboCPC.

system flash V0.46

added code to be compatible with Turbo CPC core.


system flash V0.44

- new IDE/flashcard timing should improve compatibility

- some cleanup in BitBoot, handling of cards with lots of deleted files debugged

- Silversurfer is now only used on it's upper mirror addresses (future compatibility with other clockport products)

- BigBoot now initializes the S-Ram on the CPU/RAM card with 0, so the C64 core does not need an init memory file any more. This also ensures safe startup of all cores.

- inner loop of the IDE poll routine now written in RISC assembler, improving speed by 25%
