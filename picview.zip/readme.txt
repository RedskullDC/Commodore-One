I would like to write some little useful C-One Cores to show the future of the board.

First Part is a Picture viewer for 65536 colors. The picture must be 320x204 pixels in size. This is the maximum for the 128KB SRAM of the C-One.

You can convert your own image with Irfanview into RGB RAW mode. Then convert it with raw2cone to the c-one raw mode:
B 5bit, G 6bit, R 5bit.
This archive includes the files for the boot folder, the quartus 5.0 snapshot of the FPGA core, and the cpp-source for the raw2cone converter.


Enjoy
TobiFlex  


