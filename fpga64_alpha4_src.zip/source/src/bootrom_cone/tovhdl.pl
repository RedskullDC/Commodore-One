
sub toVhdl {
	my $sourceName = shift;
	my $destName = shift;
	my $romSize = shift;
	my $charRom = shift;
	my $buffer;

	open SRC, "$sourceName" || die "src!";
	open DEST, ">$destName" || die "dst!";

	binmode SRC;
	
	read SRC, $buffer, $romSize;
	for(my $i=0;$i < $romSize; $i++) {
		if (($charRom == '0') or ($i<1024) or (($i>=2048) and ($i<3072))) {
			if (($i & 15) == 0) {
				print DEST "\n";
			}
			print DEST sprintf("X\"%02X\", ", ord(substr($buffer, $i)));
		}
	}	
	close SRC;
	close DEST;
}

#toVhdl('basic', 'basic.vhdl', 8192, 0);
#toVhdl('kernal', 'kernal.vhdl', 8192, 0);
#toVhdl('chargen', 'chargen.vhdl', 4096, 1);
toVhdl('bootrom.bin', 'bootrom.vhdl', 4096, 0);
