 /*
Copyright 2005, 2006, 2007 Dennis van Weeren

This file is part of Minimig

Minimig is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

Minimig is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Minimig boot controller / floppy emulator / on screen display

27-11-2005              -started coding
29-01-2005              -done a lot of work
06-02-2006              -it start to look like something!
19-02-2006              -improved floppy dma offset code
02-01-2007              -added osd support
11-02-2007              -added insert floppy progress bar
01-07-2007              -added filetype filtering for directory routines

JB:

2008-07-18              -better read support (sector loaders are now less confused)
                                -write support added (strict sector format checking - may not work with non DOS games)
                                -removed bug in filename filtering (initial directory fill didn't filter)
                                -communication interface with new bootloader
                                -OSD control of reset, ram configuration, interpolation filters and kickstart

                                WriteTrack errors:
                                #20 : unexpected dma transfer end (sector header)
                                #21 : no second sync word found
                                #22 : first header byte not 0xFF
                                #23 : second header byte (track number) not within 0..159 range
                                #24 : third header byte (sector number) not within 0..10 range
                                #25 : fourth header byte (sectors to gap number) not within 1..11 range
                                #26 : header checksum error
                                #27 : track number in sector header not the same as drive head position
                                #28 : unexpected dma transfer end (sector data)
                                #29 : data checksum error
                                #30 : write attempt to protected disk

2008-07-25              -update of write sector header format checking
                                -disk led active during writes to disk

TobiFlex:
2008-11-...			port to C-One
					rewrite some parts in 68000 asm code
*/

#include <stdio.h>
#include <string.h>
#include "osd.h"
#include "fat1618_2.h"

//#define DEBUG

void CheckTrack(struct adfTYPE *drive);
void ReadTrack(struct adfTYPE *drive);
void WriteTrack(struct adfTYPE *drive);
unsigned char FindSync(struct adfTYPE *drive);
unsigned char GetHeader(unsigned char *pTrack, unsigned char *pSector);
unsigned char GetData();

//char BootPrint(const char* text);
void BootExit(void);
void ErrorMessage(const char* message, unsigned char code);
unsigned short SectorToFpga(unsigned char sector,unsigned char track);
void SectorGapToFpga(void);
void SectorHeaderToFpga(unsigned char);

void HandleFpgaCmd(unsigned char c1, unsigned char c2);
void InsertFloppy(struct adfTYPE *drive);

void PrintDir(void);
void User(void);

/*FPGA commands <c1> argument*/
#define         CMD_USERSELECT          0x80    /*user interface SELECT*/
#define         CMD_USERUP                      0x40    /*user interface UP*/
#define         CMD_USERDOWN            0x20    /*user interface DOWN*/
#define         CMD_GETDSKSTAT          0x04    /*FPGA requests status of disk drive*/
#define         CMD_RDTRCK                      0x02    /*FPGA requests reading of track <c2>*/
#define         CMD_WRTRCK                      0x01    /*FPGA requests writing of trck <c2>*/

#define         ST_READREQ      0x02

/*floppy status*/
#define         DSK_INSERTED            0x01    /*disk is inserted*/
#define         DSK_WRITABLE            0x02    /*disk is writable*/

/*menu states*/
#define         MENU_NONE1                      0               /*no menu*/
#define         MENU_NONE2                      1               /*no menu*/
#define         MENU_MAIN1                      2               /*main menu*/
#define         MENU_MAIN2                      3               /*main menu*/
#define         MENU_FILE1                      4               /*file requester menu*/
#define         MENU_FILE2                      5               /*file requester menu*/
#define         MENU_RESET1                     6               /*reset menu*/
#define         MENU_RESET2                     7               /*reset menu*/
#define         MENU_SETTINGS1          8               /*settings menu*/
#define         MENU_SETTINGS2          9               /*settings menu*/
#define         MENU_ROMSELECT1         10              /*rom select menu*/
#define         MENU_ROMSELECT2         11              /*rom select menu*/
#define         MENU_ROMFILE1           12              /*rom file select menu*/
#define         MENU_ROMFILE2           13              /*rom file select menu*/
#define         MENU_ERROR                      127             /*error message menu*/

/*other constants*/
#define         DIRSIZE                         8               /*size of directory display window*/
#define         REPEATTIME                      50              /*repeat delay in 10ms units*/
#define         REPEATRATE                      5               /*repeat rate in 10ms units*/

#define         EEPROM_LRFILTER         0x10
#define         EEPROM_HRFILTER         0x11
#define         EEPROM_MEMCFG           0x12
#define         EEPROM_KICKNAME         0x18    /*size 8*/

#define         MOUNT_ENTRIES         0x8    /*size 8*/

/*variables*/
struct adfTYPE
{
        unsigned short entries;                         /*max. possible fragments */
        unsigned long fragment[2*MOUNT_ENTRIES];        /*fragments*/
        unsigned char status;                           /*status of floppy*/
        unsigned char sectoroffset;                     /*sector offset to handle tricky loaders*/
        unsigned char track;                            /*current track*/
        unsigned char trackprev;                        /*previous track*/
        unsigned char name[12];                         /*floppy name*/
};

struct adfTYPE df0,df1,df2,df3,*aktdrive,*seldrive;                                             /*drive 0 information structure*/
struct file2TYPE file;                                  /*global file handle*/
struct file2TYPE directory[DIRSIZE];    /*directory array*/
unsigned char dirptr;                                   /*pointer into directory array*/

//unsigned char menustate = MENU_NONE1;
unsigned char menustate;
unsigned char menusub;

unsigned char s[25];                                    /*used to build strings*/

unsigned char lr_filter;
unsigned char hr_filter;
const char* filter_msg[] = {"none","HOR ","VER ","H+V "};
unsigned char memcfg;
const char* memcfg_msg[] = {"512K CHIP","1Meg CHIP","512K/512K","1Meg/512K"};
unsigned short first_dir_entry;

unsigned char Error;

unsigned char fstype;

/*This is where it all starts after reset*/
main(void)
{
        unsigned char c1,c2/*,c3,c4*/;
        unsigned short t;
        unsigned char c;
        unsigned char i;

        OsdDisable();
		menustate = MENU_NONE1;
		menusub = 0;
		aktdrive=&df0;
        lr_filter = 0;
        hr_filter = 0;
        memcfg = 3;
        
        /*initalize FAT partition*/
        if (!FindDrive2()==0)
        {
//                puts("No filesystem found!\r");
               ErrorMessage("No filesystem found!",0);
               while(1);
        }
//        else
//        {       switch (fstype)
//				{
//					case 12:
//							puts("FAT12 filesystem found!\r");
//							break;
//					case 16:
//							puts("FAT16 filesystem found!\r");
//							break;
//					case 32:
//							puts("FAT32 filesystem found!\r");
//							break;
//				}
//        }

//        BootPrint("** 68K firmware 111108 **\n");

        df0.status=0;
        df1.status=0;
        df2.status=0;
        df3.status=0;


        if (SearchFile("KICK    ROM"))
        {
//                puts("Kick2.0 found!\r");
                LoadFile(0x280000);
        }
        else
        {
               ErrorMessage(" No KICK.ROM found!",0);
               while(1);
        }

        if (SearchFile("DF0     ADF"))
        {
//                puts("DF0.ADF found!\r");
                file.cluster=cluster;
                strncpy(file.name,"DF0     ADF",11);
                file.attributes=attrib;
                InsertFloppy(&df0);
        }

//        if (!CheckButton())     /*if menu button pressed don't load Action Replay*/
//        if (SearchFile(""AR3     ROM""))
//        {
//                puts("Uploading Action Replay ROM...\r");
//                LoadFile(0x200000);
//        }

        OsdFilter(lr_filter,hr_filter); /*set interpolation filters*/
        OsdMemoryConfig(memcfg);                /*set memory config*/
        BootExit();

        /******************************************************************************/
        /******************************************************************************/
        /*System is up now*/
        /******************************************************************************/
        /******************************************************************************/

        /*fill initial directory*/
		ReadDir("ADF",0);
		first_dir_entry=0;
		dirptr = 0;
        /*get initial timer for checking user interface*/

        while(1)
        {
                /*read command from FPGA*/
                EnableFpga();
                c1=SPI(0);
                c2=SPI(0);
                DisableFpga();
                /*handle command*/
                HandleFpgaCmd(c1,c2);

                /*handle user interface*/
                User();
        }
}

void BootExit(void)
{
        unsigned char c1,c2,c3,c4;
        while (1)
        {
                EnableFpga();
                c1 = SPI(0);
                c2 = SPI(0);
                c3 = SPI(0);
                c4 = SPI(1);    /*disk present*/
                if (c1 == CMD_RDTRCK)
                {
                        if (c3==0x80 && c4==0x06)       /*command packet size 12 bytes*/
                        {
                                SPI(0xAA);      /*command header*/
                                SPI(0x55);
                                SPI(0x00);      /*cmd: 0003 = restart*/
                                SPI(0x03);
                                /*don't care*/
                                SPI(0x00);
                                SPI(0x00);
                                SPI(0x00);
                                SPI(0x00);
                                /*don't care*/
                                SPI(0x00);
                                SPI(0x00);
                                SPI(0x00);
                                SPI(0x00);
                        }
                        DisableFpga();
                        return;
                }
                DisableFpga();
        }
}

/*user interface*/
void User(void)
{
        unsigned char c,up,down,select,menu;

        /*get user control codes*/
        c=OsdGetCtrl();

        /*decode and set events*/
        up=0;
        down=0;
        select=0;
        menu=0;
        if (c&OSDCTRLUP)
                up=1;
        if (c&OSDCTRLDOWN)
                down=1;
        if (c&OSDCTRLSELECT)
                select=1;
        if (c&OSDCTRLMENU)
                menu=1;


        /*menu state machine*/
        switch (menustate)
        {
                /******************************************************************/
                /*no menu selected / menu exited / menu not displayed*/
                /******************************************************************/
                case MENU_NONE1:
                        OsdDisable();
                        menustate=MENU_NONE2;
                        break;

                case MENU_NONE2:
                        if (menu||select)/*check if user wants to go to menu*/
                        {
                                menustate=MENU_MAIN1;
                                menusub=0;
                                OsdClear();
                                OsdEnable();
                        }
                        break;

                /******************************************************************/
                /*main menu: insert/eject floppy, reset and exit*/
                /******************************************************************/
                case MENU_MAIN1:
                        /*menu title*/
                        OsdWrite(0," ** Minimig Menu **",0);

                        /*df0 info*/
                        if (aktdrive==&df0)
							strcpy(s,"     df0: ");
                        else
							strcpy(s,"     df1: ");
                        if (aktdrive->status&DSK_INSERTED)/*floppy currently in df0*/
                                strncpy(&s[10],aktdrive->name,8);
                        else/*no floppy in df0*/
                                strncpy(&s[10],"--------",8);
                        s[18]=0x0d;
                        s[19]=0x00;
                        OsdWrite(2,s,0);

                        if (aktdrive->status&DSK_INSERTED)/*floppy currently in df0*/
                                if (aktdrive->status&DSK_WRITABLE)/*floppy is writable*/
                                        strcpy(s,"     writable ");
                                else
                                        strcpy(s,"     read only");
                        else    /*no floppy in df0*/
                                strcpy(s,"     no disk  ");
                        OsdWrite(3,s,0);

                        /*eject/insert df0 options*/
                        if (aktdrive->status&DSK_INSERTED)/*floppy currently in df0*/
                                strcpy(s,"     eject adf ");
                        else/*no floppy in df0*/
                                strcpy(s,"     insert adf");

                        OsdWrite(5,"     settings",menusub==1);
                        OsdWrite(4,s,menusub==0);

                        /*reset system*/
                        OsdWrite(6,"     reset",menusub==2);

                        /*exit menu*/
                        OsdWrite(7,"     exit",menusub==3);

                        OsdEnable();
                        /*goto to second state of main menu*/
                        menustate = MENU_MAIN2;
                        break;

                case MENU_MAIN2:

                        if (menu)/*menu pressed*/
//							if (aktdrive==&df0)
//							{	aktdrive=&df1;
//                                menustate=MENU_MAIN1;
//							}
//							else
//							{	aktdrive=&df0;
                                menustate=MENU_NONE1;
//                            }
                        else if (up)/*up pressed*/
                        {
                                if (menusub>0)
                                        menusub--;
                                menustate=MENU_MAIN1;
                        }
                        else if (down)/*down pressed*/
                        {
                                if (menusub<3)
                                        menusub++;
                                menustate=MENU_MAIN1;
                        }
                        else if (select)/*select pressed*/
                        {
                                if (menusub==0 && (aktdrive->status&DSK_INSERTED))/*eject floppy*/
                                {
                                        aktdrive->status = 0;
                                        menustate = MENU_MAIN1;
                                }
                                else if (menusub==0)/*insert floppy*/
                                {
                                        aktdrive->status = 0;
                                        menustate = MENU_FILE1;
                                        OsdClear();
                                }
                                else if (menusub==1)/*settings*/
                                {
                                        menusub = 4;
                                        menustate = MENU_SETTINGS1;
                                        OsdClear();
                                }
                                else if (menusub==2)/*reset*/
                                {
                                        menusub = 1;
                                        menustate = MENU_RESET1;
                                        OsdClear();
                                }
                                else if (menusub==3)/*exit menu*/
                                        menustate = MENU_NONE1;

                        }

                        break;

                /******************************************************************/
                /*adf file requester menu*/
                /******************************************************************/
                case MENU_FILE1:
                        PrintDir();
                        menustate=MENU_FILE2;
                        break;

                case MENU_FILE2:
                        if (down)/*scroll down through file requester*/
                        {
								if (dirptr == DIRSIZE-1)/*pointer is at bottom of directory window*/
								{		first_dir_entry++;
										ReadDir("ADF",first_dir_entry);
										if (directory[dirptr].len==0)
										{	first_dir_entry--;
											ReadDir("ADF",first_dir_entry);
										}
								}
								else/*just move pointer in window*/
								{
										if (directory[dirptr+1].len!=0)
												dirptr++;
								}
								menustate=MENU_FILE1;
						}
                        if (up)/*scroll up through file requester*/
                        {
								if (dirptr==0)/*pointer is at top of directory window*/
								{
										if (first_dir_entry>0)
										{	first_dir_entry--;
											ReadDir("ADF",first_dir_entry);
										}
								}
								else
										dirptr--;
								menustate=MENU_FILE1;
                       }

                        if (select)/*insert floppy*/
                        {
                                menustate = MENU_MAIN1;
//                                menusub = 3;
                                OsdClear();
//                                if (directory[dirptr].len)
//                                {
                                        file = directory[dirptr];
										menustate = MENU_NONE1;
                                        InsertFloppy(aktdrive);
//                                }
                        }

                        if (menu)/*return to main menu*/
                        {
                                menustate = MENU_MAIN1;
                                menusub = 0;
                                OsdClear();
                        }
                        break;
                /******************************************************************/
                /*reset menu*/
                /******************************************************************/
                case MENU_RESET1:
                        /*menu title*/
                        OsdWrite(0,"    Reset Minimig?",0);
                        OsdWrite(2,"      yes",menusub==0);
                        OsdWrite(3,"      no",menusub==1);

                        /*goto to second state of reset menu*/
                        menustate = MENU_RESET2;
                        break;

                case MENU_RESET2:
                        if (down && menusub<1)
                        {
                                menusub++;
                                menustate = MENU_RESET1;
                        }

                        if (up && menusub>0)
                        {
                                menusub--;
                                menustate = MENU_RESET1;
                        }

                        if (select)
                        {
                                if (menusub==0)
                                {
                                        OsdReset(0);
                                        menustate = MENU_NONE1;
                                }
                        }

                        if (menu || (select && menusub==1))/*exit menu*/
                        {
                                        menustate = MENU_MAIN1;
                                        menusub = 2;
                                        OsdClear();
                        }
                        break;
//                /******************************************************************/
//                /*settings menu*/
//                /******************************************************************/
                case MENU_SETTINGS1:
                        /*menu title*/
                        OsdWrite(0,"   ** SETTINGS **",0);

                        strcpy(s,"  Lores Filter: ");
                        strcpy(&s[16],filter_msg[lr_filter]);
                        OsdWrite(2,s,menusub==0);

                        strcpy(s,"  Hires Filter: ");
                        strcpy(&s[16],filter_msg[hr_filter]);
                        OsdWrite(3,s,menusub==1);

                        strcpy(s,"  RAM: ");
                        strcpy(&s[7],memcfg_msg[memcfg]);
                        OsdWrite(4,s,menusub==2);

                        OsdWrite(7,"        exit",menusub==3);

                        /*goto to second state of reset menu*/
                        menustate = MENU_SETTINGS2;
                        break;

                case MENU_SETTINGS2:
                        if (down && menusub<3)
                        {
                                menusub++;
                                menustate = MENU_SETTINGS1;
                        }

                        if (up && menusub>0)
                        {
                                menusub--;
                                menustate = MENU_SETTINGS1;
                        }

                        if (select)
                        {
                                if (menusub==0)
                                {
                                        lr_filter++;
                                        lr_filter &= 0x03;
                                        menustate = MENU_SETTINGS1;
                                        OsdFilter(lr_filter,hr_filter);
                                }
                                else if (menusub==1)
                                {
                                        hr_filter++;
                                        hr_filter &= 0x03;
                                        menustate = MENU_SETTINGS1;
                                        OsdFilter(lr_filter,hr_filter);
                                }
                                else if (menusub==2)
                                {
                                        memcfg++;
                                        memcfg &= 0x03;
                                        menustate = MENU_SETTINGS1;
                                        OsdMemoryConfig(memcfg);
                                }

                        }

                        if (menu || (select && menusub==3)) /*return to main menu*/
                        {
                                        menustate = MENU_MAIN1;
                                        menusub = 1;
                                        OsdClear();
                        }
                        break;

                /******************************************************************/
                /*error message menu*/
                /******************************************************************/
                case MENU_ERROR:
                        if (menu||select) /*exit when menu button is pressed*/
                        {
                                menustate = MENU_NONE1;
                        }
                        break;
                /******************************************************************/
                /*we should never come here*/
                /******************************************************************/
                default:
                                menustate = MENU_MAIN1;
                        break;
        }
}

void ErrorMessage(const char* message, unsigned char code)
{
        menustate = MENU_ERROR;
        OsdClear();
        OsdWrite(0,"    *** ERROR ***",1);
        strncpy(s,message,21);
        s[21] = 0;
        OsdWrite(2,s,0);
        if (code)
        {
                strcpy(s,"  error #     ");
                s[9]=code/10+0x30;
                s[10]=code%10+0x30;
                OsdWrite(4,s,0);
        }
        OsdEnable();
}

/*print the contents of directory[] and the pointer dirptr onto the OSD*/
void PrintDir(void)
{
        unsigned char i;

        for(i=0;i<21;i++)
                s[i] = ' ';
        s[21] = 0;

        if (directory[0].len==0)
                OsdWrite(1,"   No files!",1);
        else
        for(i=0;i<DIRSIZE;i++)
        {
                strncpy(&s[3],directory[i].name,8);
                OsdWrite(i,s,i==dirptr);
        }

}


/*insert floppy image pointed to to by global <file> into <drive>*/
void InsertFloppy(struct adfTYPE *drive)
{
	unsigned char i;
		drive->entries=MOUNT_ENTRIES;
		drive->fragment[1]=file.cluster;
		if (MountFile(drive))
			drive->status = DSK_INSERTED;
		else
			ErrorMessage("more then 8 fragments",0);

        /*copy name*/
        for(i=0;i<12;i++)
                drive->name[i]=file.name[i];

        /*initialize rest of struct*/
        if (!(file.attributes&0x01))/*read-only attribute*/
                drive->status |= DSK_WRITABLE;
        drive->sectoroffset=0;
        drive->track=0;
        drive->trackprev=-1;
//      puts("Inserting floppy: ");
//		puts(&file.name[0]);
}



/*Handle an FPGA command*/
void HandleFpgaCmd(unsigned char c1, unsigned char c2)
{
	unsigned short sel;

	sel=OSD(0);
	seldrive=&df0;
//	if (!(sel&0x0800))
//	{	seldrive=&df0;putch('0');}
//	if (!(sel&0x1000))
//	{	seldrive=&df1;putch('1');}
//	if (!(sel&0x2000))
//	{	seldrive=&df2;putch('2');}
//	if (!(sel&0x4000))
//	{	seldrive=&df3;putch('3');}

        /*c1 is command byte*/
        switch(c1&(CMD_GETDSKSTAT|CMD_RDTRCK|CMD_WRTRCK))
        {
                /*FPGA is requesting track status*/
                case CMD_GETDSKSTAT:
                        CheckTrack(seldrive);
                        break;

                /*FPGA wants to read a track
                c2 is track number*/
                case CMD_RDTRCK:
                        seldrive->track=c2;
/*                      DISKLED=1;
*/                      ReadTrack(seldrive);
/*                      DISKLED=0;
*/                      break;

                /*FPGA wants to write a track
                c2 is track number*/
                case CMD_WRTRCK:
                        seldrive->track=c2;
/*                      DISKLED=1;
*/                      WriteTrack(seldrive);
/*                      DISKLED=0;
*/                      break;

                /*no command*/
                default:
                        break;
        }
}

/*CheckTrack, respond with disk status*/
void CheckTrack(struct adfTYPE *drive)
{
        EnableFpga();
        SPI(0x00);
        SPI(0x00);
        SPI(0x00);
        SPI(drive->status);
        DisableFpga();
}

/*read a track from disk*/
void ReadTrack(struct adfTYPE *drive)
{       /*track number is updated in drive struct before calling this function*/

        unsigned char sector;
        unsigned char c1,c2,c3,c4;
        unsigned short n;

        /*display track number: cylinder & head*/
/*#ifdef DEBUG
        puts("*%d:",drive->track);
#endif
*/
        if (drive->track != drive->trackprev)
        {/*track step or track 0, start at beginning of track*/
                drive->trackprev = drive->track;
                sector           = 0;
                file.sec         = drive->track*11;
                drive->sectoroffset = sector;
        }
        else
        {/*same track, start at next sector in track*/
                sector       = drive->sectoroffset;
                file.sec     = (drive->track*11)+sector;
        }

        EnableFpga();

        c1 = SPI(0);            /*read request signal*/
        c2 = SPI(0);            /*track number (cylinder & head)*/
        c3 = 0x3F&SPI(0);       /*msb of mfm words to transfer */
        c4 = SPI(drive->status);                /*lsb of mfm words to transfer*/

        DisableFpga();

        /* if dma read count is bigger than 11 sectors then we start the transfer from the begining of current track*/
        if ((c3>0x17) || (c3==0x17 && c4>=0x60))
        {
                sector           = 0;
                file.sec         = drive->track*11;
        }

        while (1)
        {
				SectorRead(drive, file.sec);

                EnableFpga();

                /*check if FPGA is still asking for data*/
                c1 = SPI(0);    /*read request signal*/
                c2 = SPI(0);    /*track number (cylinder & head)*/
                c3 = SPI(0);    /*msb of mfm words to transfer*/
                c4 = SPI(drive->status);        /*lsb of mfm words to transfer*/

/*      #ifdef DEBUG
                c = sector + '0';
                if (c>'9')
                        c += 'A'-'9'-1;
                putchar(c);
                putchar(':');
                c = ((c3>>4)&0xF) + '0';
                if (c>'9')
                        c += 'A'-'9'-1;
                putchar(c);
                c = (c3&0xF) + '0';
                if (c>'9')
                        c += 'A'-'9'-1;
                putchar(c);

                c = ((c4>>4)&0xF) + '0';
                if (c>'9')
                        c += 'A'-'9'-1;
                putchar(c);
                c = (c4&0xF) + '0';
                if (c>'9')
                        c += 'A'-'9'-1;
                putchar(c);
        #endif
*/
                c3 &= 0x3F;

                /*some loaders stop dma if sector header isn't what they expect
                  we don't check dma transfer count after sending every word
                  so the track can be changed while we are sending the rest of the previous sector
                  in this case let's start transfer from the beginning*/
                if (c2 == drive->track)
                /*send sector if fpga is still asking for data*/
                if (c1&0x02)
                {
                        if (c3==0 && c4<4)
                                SectorHeaderToFpga(c4);
                        else
                        {
                                n = SectorToFpga(sector,drive->track);


/*                      #ifdef DEBUG    */                              /* printing remaining dma count */
/*                              putchar('-');
                                c = ((n>>12)&0xF) + '0';
                                if (c>'9')
                                        c += 'A'-'9'-1;
                                putchar(c);
                                c = ((n>>8)&0xF) + '0';
                                if (c>'9')
                                        c += 'A'-'9'-1;
                                putchar(c);

                                c = ((n>>4)&0xF) + '0';
                                if (c>'9')
                                        c += 'A'-'9'-1;
                                putchar(c);
                                c = (n&0xF) + '0';
                                if (c>'9')
                                        c += 'A'-'9'-1;
                                putchar(c);
                        #endif
*/
                                n--;
                                c3 = (n>>8)&0x3F;
                                c4 = n;

                                if (c3==0 && c4<4)
                                {
                                        SectorHeaderToFpga(c4);
/*                              #ifdef DEBUG
                                        putchar('+');
                                        c4 += '0';
                                        putchar(c4);
                                #endif
*/                              }
                                else
                                if (sector==10)
                                {
                                        SectorGapToFpga();
/*                              #ifdef DEBUG
                                        putchar('+');
                                        putchar('+');
                                        putchar('+');
                                #endif
*/                              }
                        }
                }

                /*we are done accessing FPGA*/
                DisableFpga();

                /*track has changed*/
                if (c2 != drive->track)
                        break;

                /*read dma request*/
                if (!(c1&0x02))
                        break;


                /*don't go to the next sector if there is not enough data in the fifo*/
                if (c3==0 && c4<4)
                        break;

                /* go to the next sector*/
                sector++;
                if (sector<11)
                {
                        file.sec++;
                }
                else    /*go to the start of current track*/
                {
                        sector       = 0;
                        file.sec     = drive->track*11;
                }

                /*remember current sector and cluster*/
                drive->sectoroffset  = sector;

/*      #ifdef DEBUG
                putchar('-');
                putchar('>');
        #endif
*/
        }

/*#ifdef DEBUG
        putchar(':');
        putchar('O');
        putchar('K');
        putchar('\r');
#endif
*/

}

void WriteTrack(struct adfTYPE *drive)
{
        unsigned char sector;
        unsigned char Track;
        unsigned char Sector;

        /*setting file pointer to begining of current track*/
        file.sec     = drive->track*11;
        sector = 0;

        drive->trackprev = drive->track+1;      /*just to force next read from the start of current track*/

/*#ifdef DEBUG
        puts("*%d:\r",drive->track);
#endif
*/
        while (FindSync(drive))
        {
                if (GetHeader(&Track,&Sector))
                {
                        if (Track == drive->track)
                        {
                                while (sector != Sector)
                                {
                                        if (sector < Sector)
                                        {
												file.sec++;
                                                sector++;
                                        }
                                        else
                                        {
                                                file.sec     = drive->track*11;
                                                sector = 0;
                                        }
                                }

                                if (GetData())
                                {
                                        if (drive->status&DSK_WRITABLE)
                                                SectorWrite(drive, file.sec);

                                        else
                                        {
                                                Error = 30;
//                                                puts("Write attempt to protected disk!\r");
                                        }
                                }
                        }
                        else
                                Error = 27;             /*track number reported in sector header is not the same as current drive track*/
                }
                if (Error)
                {
//                        puts("WriteTrack: error %d\r",Error);
//                        ErrorMessage("  WriteTrack",Error);
//                        puts("WriteTrack error \r");
                        ErrorMessage("  WriteTrack",Error);
                }
        }

}

unsigned char FindSync(struct adfTYPE *drive)
/*this function reads data from fifo till it finds sync word
 or fifo is empty and dma inactive (so no more data is expected)*/
{
        unsigned char c1,c2,c3,c4;
        unsigned short n;

        while (1)
        {
                EnableFpga();
                c1 = SPI(0);                    /*write request signal*/
                c2 = SPI(0);                    /*track number (cylinder & head)*/
                if (!(c1&CMD_WRTRCK))
                        break;
                if (c2 != drive->track)
                        break;
                c3 = SPI(0)&0xBF;               /*msb of mfm words to transfer*/
                c4 = SPI(0);                    /*lsb of mfm words to transfer*/

                if (c3==0 && c4==0)
                        break;

                n = ((c3&0x3F)<<8) + c4;

                while (n--)
                {
                        c3 = SPI(0);
                        c4 = SPI(0);
                        if (c3==0x44 && c4==0x89)
                        {
                                DisableFpga();
/*                      #ifdef DEBUG
                                puts("#SYNC:");
                        #endif
*/                              return 1;
                        }
                }
                DisableFpga();
        }
        DisableFpga();
        return 0;
}

unsigned char GetHeader(unsigned char *pTrack, unsigned char *pSector)
/*this function reads data from fifo till it finds sync word or dma is inactive*/
{
        unsigned char c,c1,c2,c3,c4;
        unsigned char i;
        unsigned char checksum[4];

        Error = 0;
        while (1)
        {
                EnableFpga();
                c1 = SPI(0);                    /*write request signal*/
                c2 = SPI(0);                    /*track number (cylinder & head)*/
                if (!(c1&CMD_WRTRCK))
                        break;
                c3 = SPI(0);                    /*msb of mfm words to transfer*/
                c4 = SPI(0);                    /*lsb of mfm words to transfer*/

                if ((c3&0x3F)!=0 || c4>24)      /*remaining header data is 25 mfm words*/
                {
                        c1 = SPI(0);            /*second sync lsb*/
                        c2 = SPI(0);            /*second sync msb*/
                        if (c1!=0x44 || c2!=0x89)
                        {
                                Error = 21;
//                                puts("\rSecond sync word missing...\r",c1,c2,c3,c4);
                                break;
                        }

                        c = SPI(0);
                        checksum[0] = c;
                        c1 = (c&0x55)<<1;
                        c = SPI(0);
                        checksum[1] = c;
                        c2 = (c&0x55)<<1;
                        c = SPI(0);
                        checksum[2] = c;
                        c3 = (c&0x55)<<1;
                        c = SPI(0);
                        checksum[3] = c;
                        c4 = (c&0x55)<<1;

                        c = SPI(0);
                        checksum[0] ^= c;
                        c1 |= c&0x55;
                        c = SPI(0);
                        checksum[1] ^= c;
                        c2 |= c&0x55;
                        c = SPI(0);
                        checksum[2] ^= c;
                        c3 |= c&0x55;
                        c = SPI(0);
                        checksum[3] ^= c;
                        c4 |= c&0x55;

                        if (c1 != 0xFF)         /*always 0xFF*/
                                Error = 22;
                        else if (c2 > 159)              /*Track number (0-159)*/
                                Error = 23;
                        else if (c3 > 10)               /*Sector number (0-10)*/
                                Error = 24;
                        else if (c4>11 || c4==0)        /*Number of sectors to gap (1-11)*/
                                Error = 25;

                        if (Error)
                        {
//                                puts("\rWrong header: %d.%d.%d.%d\r",c1,c2,c3,c4);
                                break;
                        }

/*              #ifdef DEBUG
                        puts("T%dS%d\r",c2,c3);
                #endif
*/
                        *pTrack = c2;
                        *pSector = c3;

                        for (i=0;i<8;i++)
                        {
                                checksum[0] ^= SPI(0);
                                checksum[1] ^= SPI(0);
                                checksum[2] ^= SPI(0);
                                checksum[3] ^= SPI(0);
                        }

                        checksum[0] &= 0x55;
                        checksum[1] &= 0x55;
                        checksum[2] &= 0x55;
                        checksum[3] &= 0x55;

                        c1 = (SPI(0)&0x55)<<1;
                        c2 = (SPI(0)&0x55)<<1;
                        c3 = (SPI(0)&0x55)<<1;
                        c4 = (SPI(0)&0x55)<<1;

                        c1 |= SPI(0)&0x55;
                        c2 |= SPI(0)&0x55;
                        c3 |= SPI(0)&0x55;
                        c4 |= SPI(0)&0x55;

                        if (c1!=checksum[0] || c2!=checksum[1] || c3!=checksum[2] || c4!=checksum[3])
                        {
                                Error = 26;
                                break;
                        }

                        DisableFpga();
                        return 1;
                }
                else                            /*not enough data for header*/
                if ((c3&0x80)==0)       /*write dma is not active*/
                {
                        Error = 20;
                        break;
                }

                DisableFpga();
        }

        DisableFpga();
        return 0;
}

unsigned char GetData()
{
        unsigned char c,c1,c2,c3,c4;
        unsigned char i;
        unsigned char *p;
        unsigned short n;
        unsigned char checksum[4];

        Error = 0;
        while (1)
        {
                EnableFpga();
                c1 = SPI(0);                    /*write request signal*/
                c2 = SPI(0);                    /*track number (cylinder & head)*/
                if (!(c1&CMD_WRTRCK))
                        break;
                c3 = SPI(0);                    /*msb of mfm words to transfer*/
                c4 = SPI(0);                    /*lsb of mfm words to transfer*/

                n = ((c3&0x3F)<<8) + c4;

                if (n >= 0x204)
                {
                        c1 = (SPI(0)&0x55)<<1;
                        c2 = (SPI(0)&0x55)<<1;
                        c3 = (SPI(0)&0x55)<<1;
                        c4 = (SPI(0)&0x55)<<1;

                        c1 |= SPI(0)&0x55;
                        c2 |= SPI(0)&0x55;
                        c3 |= SPI(0)&0x55;
                        c4 |= SPI(0)&0x55;

                        checksum[0] = 0;
                        checksum[1] = 0;
                        checksum[2] = 0;
                        checksum[3] = 0;

                        /*odd bits of data field*/
                        i = 128;
                        p = secbuf;
                        do
                        {
                                c = SPI(0);
                                checksum[0] ^= c;
                                *p++ = (c&0x55)<<1;
                                c = SPI(0);
                                checksum[1] ^= c;
                                *p++ = (c&0x55)<<1;
                                c = SPI(0);
                                checksum[2] ^= c;
                                *p++ = (c&0x55)<<1;
                                c = SPI(0);
                                checksum[3] ^= c;
                                *p++ = (c&0x55)<<1;
                        }
                        while(--i);

                        /*even bits of data field*/
                        i = 128;
                        p = secbuf;
                        do
                        {
                                c = SPI(0);
                                checksum[0] ^= c;
                                *p++ |= c&0x55;
                                c = SPI(0);
                                checksum[1] ^= c;
                                *p++ |= c&0x55;
                                c = SPI(0);
                                checksum[2] ^= c;
                                *p++ |= c&0x55;
                                c = SPI(0);
                                checksum[3] ^= c;
                                *p++ |= c&0x55;
                        }
                        while(--i);

                        checksum[0] &= 0x55;
                        checksum[1] &= 0x55;
                        checksum[2] &= 0x55;
                        checksum[3] &= 0x55;

                        if (c1!=checksum[0] || c2!=checksum[1] || c3!=checksum[2] || c4!=checksum[3])
                        {
                                Error = 29;
                                break;
                        }

                        DisableFpga();
                        return 1;
                }
                else                            /*not enough data in fifo*/
                if ((c3&0x80)==0)       /*write dma is not active*/
                {
                        Error = 28;
                        break;
                }

                DisableFpga();
        }
        DisableFpga();
        return 0;
}

/*this function sends the data in the sector buffer to the FPGA, translated
into an Amiga floppy format sector
sector is the sector number in the track
track is the track number
note that we do not insert clock bits because they will be stripped
by the Amiga software anyway*/
unsigned short SectorToFpga(unsigned char sector,unsigned char track)
{
        unsigned char c,i;
        unsigned char csum[4];
        unsigned char *p;
        unsigned char c3,c4;

        /*preamble*/
        SPI(0xaa);
        SPI(0xaa);
        SPI(0xaa);
        SPI(0xaa);

        /*synchronization*/
        SPI(0x44);
        SPI(0x89);
        SPI(0x44);
        SPI(0x89);

        /*clear header checksum*/
        csum[0]=0;
        csum[1]=0;
        csum[2]=0;
        csum[3]=0;

        /*odd bits of header*/
        c=0x55;
        csum[0]^=c;
        SPI(c);
        c=(track>>1)&0x55;
        csum[1]^=c;
        SPI(c);
        c=(sector>>1)&0x55;
        csum[2]^=c;
        SPI(c);
        c=((11-sector)>>1)&0x55;
        csum[3]^=c;
        SPI(c);

        /*even bits of header*/
        c=0x55;
        csum[0]^=c;
        SPI(c);
        c=track&0x55;
        csum[1]^=c;
        SPI(c);
        c=sector&0x55;
        csum[2]^=c;
        SPI(c);
        c=(11-sector)&0x55;
        csum[3]^=c;
        SPI(c);

        /*sector label and reserved area (changes nothing to checksum)*/
        for(i=0;i<32;i++)
                SPI(0x55);

        /*checksum over header*/
        SPI((csum[0]>>1)|0xaa);
        SPI((csum[1]>>1)|0xaa);
        SPI((csum[2]>>1)|0xaa);
        SPI((csum[3]>>1)|0xaa);
        SPI(csum[0]|0xaa);
        SPI(csum[1]|0xaa);
        SPI(csum[2]|0xaa);
        SPI(csum[3]|0xaa);

        /*calculate data checksum*/
        csum[0]=0;
        csum[1]=0;
        csum[2]=0;
        csum[3]=0;
        i=128;
        p=secbuf;
        do
        {
                c=*(p++);
                csum[0]^=c>>1;
                csum[0]^=c;
                c=*(p++);
                csum[1]^=c>>1;
                csum[1]^=c;
                c=*(p++);
                csum[2]^=c>>1;
                csum[2]^=c;
                c=*(p++);
                csum[3]^=c>>1;
                csum[3]^=c;
        }
        while(--i);
        csum[0]&=0x55;
        csum[1]&=0x55;
        csum[2]&=0x55;
        csum[3]&=0x55;


        /*checksum over data*/
        SPI((csum[0]>>1)|0xaa);
        SPI((csum[1]>>1)|0xaa);
        SPI((csum[2]>>1)|0xaa);
        SPI((csum[3]>>1)|0xaa);
        SPI(csum[0]|0xaa);
        SPI(csum[1]|0xaa);
        SPI(csum[2]|0xaa);
        SPI(csum[3]|0xaa);

        /*odd bits of data field*/
        i=128;
        p=secbuf;
        do
        {
                c=*(p++);
                c>>=1;
                c|=0xaa;
                SPI(c);

                c=*(p++);
                c>>=1;
                c|=0xaa;
                SPI(c);

                c=*(p++);
                c>>=1;
                c|=0xaa;
                SPI(c);

                c=*(p++);
                c>>=1;
                c|=0xaa;
                SPI(c);
      }
        while(--i);

        /*even bits of data field*/
        i=128;
        p=secbuf;
        do
        {
                c=*(p++);
                SPI(c|0xaa);
                c=*(p++);
                SPI(c|0xaa);
                c=*(p++);
                SPI(c|0xaa);
                c=*(p++);
                SPI(c|0xaa);
        }
        while(--i);

        return((c3<<8)|c4);
}


void SectorGapToFpga()
{
        unsigned char i;
        i = 190;
        do
        {
                SPI(0xAA);
                SPI(0xAA);
        }
        while (--i);
}

void SectorHeaderToFpga(unsigned char n)
{
        if (n)
        {
                SPI(0xAA);
                SPI(0xAA);

                if (--n)
                {
                        SPI(0xAA);
                        SPI(0xAA);

                        if (--n)
                        {
                                SPI(0x44);
                                SPI(0x89);
                        }
                }
        }
}